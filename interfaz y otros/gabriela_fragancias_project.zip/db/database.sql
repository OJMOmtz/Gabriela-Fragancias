
-- Tabla Marca
CREATE TABLE Marca (
    id_marca SERIAL PRIMARY KEY,
    nombre_marca VARCHAR(100) NOT NULL,
    ano_fundacion INTEGER,
    sede VARCHAR(100)
);

-- Tabla Perfume
CREATE TABLE Perfume (
    id_perfume SERIAL PRIMARY KEY,
    nombre_perfume VARCHAR(200) NOT NULL,
    id_marca INTEGER REFERENCES Marca(id_marca) ON DELETE CASCADE,
    ano_lanzamiento INTEGER,
    perfumero VARCHAR(100),
    notas_olfativas TEXT,
    costo DECIMAL(10, 2),
    precio_venta_credito DECIMAL(10, 2),
    precio_venta_contado DECIMAL(10, 2),
    segmento VARCHAR(50),
    franja_etaria VARCHAR(50),
    ocasion VARCHAR(50),
    intensidad VARCHAR(20),
    concentracion VARCHAR(20),
    duracion VARCHAR(50),
    estilo VARCHAR(50)
);

-- Tabla Presentacion
CREATE TABLE Presentacion (
    id_presentacion SERIAL PRIMARY KEY,
    id_perfume INTEGER REFERENCES Perfume(id_perfume) ON DELETE CASCADE,
    codigo_barra VARCHAR(50) UNIQUE NOT NULL,
    tamano_ml INTEGER CHECK (tamano_ml > 0),
    imagen_url VARCHAR(255)
);

-- Tabla Cliente
CREATE TABLE Cliente (
    id_cliente SERIAL PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    apellido VARCHAR(100) NOT NULL,
    cedula_ruc VARCHAR(20) UNIQUE NOT NULL,
    email VARCHAR(100) CHECK (email LIKE '%_@_%._%'),
    telefono VARCHAR(20),
    direccion TEXT,
    tipo_pago VARCHAR(20),
    grupo_economico VARCHAR(50),
    sexo CHAR(1) CHECK (sexo IN ('M', 'F')),
    edad INTEGER CHECK (edad >= 18)
);

-- Tabla Vendedor
CREATE TABLE Vendedor (
    id_vendedor SERIAL PRIMARY KEY,
    nombre VARCHAR(100),
    apellido VARCHAR(100),
    cedula VARCHAR(20) UNIQUE,
    telefono VARCHAR(20),
    zona VARCHAR(50)
);

-- Tabla Venta
CREATE TABLE Venta (
    id_venta SERIAL PRIMARY KEY,
    id_cliente INTEGER REFERENCES Cliente(id_cliente) ON DELETE CASCADE,
    id_vendedor INTEGER REFERENCES Vendedor(id_vendedor) ON DELETE CASCADE,
    fecha_venta TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    total DECIMAL(10, 2),
    estado VARCHAR(20) CHECK (estado IN ('pendiente', 'pagado', 'cancelado')),
    entrega_inmediata BOOLEAN DEFAULT TRUE
);

-- Tabla DetalleVenta
CREATE TABLE DetalleVenta (
    id_detalle_venta SERIAL PRIMARY KEY,
    id_venta INTEGER REFERENCES Venta(id_venta) ON DELETE CASCADE,
    id_presentacion INTEGER REFERENCES Presentacion(id_presentacion) ON DELETE CASCADE,
    cantidad INTEGER CHECK (cantidad > 0),
    precio_unitario DECIMAL(10, 2),
    subtotal DECIMAL(10, 2) GENERATED ALWAYS AS (cantidad * precio_unitario) STORED
);

-- Tabla Inventario
CREATE TABLE Inventario (
    id_inventario SERIAL PRIMARY KEY,
    ubicacion VARCHAR(50),
    id_presentacion INTEGER REFERENCES Presentacion(id_presentacion) ON DELETE CASCADE,
    stock INTEGER CHECK (stock >= 0)
);

-- Trigger para actualizar el stock al vender
CREATE OR REPLACE FUNCTION actualizar_stock() RETURNS TRIGGER AS $$
BEGIN
    IF NEW.cantidad > OLD.stock THEN
        RAISE EXCEPTION 'No hay suficiente stock';
    ELSE
        UPDATE Inventario SET stock = stock - NEW.cantidad WHERE id_presentacion = NEW.id_presentacion;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER tg_actualizar_stock
AFTER INSERT ON DetalleVenta
FOR EACH ROW EXECUTE FUNCTION actualizar_stock();
