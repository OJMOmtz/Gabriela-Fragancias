
from django.db import models
from django.core.exceptions import ValidationError

class Marca(models.Model):
    nombre_marca = models.CharField(max_length=100, unique=True)
    ano_fundacion = models.IntegerField(null=True, blank=True)
    sede = models.CharField(max_length=100, null=True, blank=True)

    def __str__(self):
        return self.nombre_marca

class Perfume(models.Model):
    nombre_perfume = models.CharField(max_length=200)
    marca = models.ForeignKey(Marca, on_delete=models.CASCADE)
    ano_lanzamiento = models.IntegerField(null=True, blank=True)
    costo = models.DecimalField(max_digits=10, decimal_places=2)
    precio_venta_credito = models.DecimalField(max_digits=10, decimal_places=2)
    precio_venta_contado = models.DecimalField(max_digits=10, decimal_places=2)

    def clean(self):
        if self.precio_venta_credito < self.costo or self.precio_venta_contado < self.costo:
            raise ValidationError('El precio de venta no puede ser menor al costo.')

    def __str__(self):
        return f"{self.nombre_perfume} - {self.marca.nombre_marca}"

class Presentacion(models.Model):
    perfume = models.ForeignKey(Perfume, on_delete=models.CASCADE)
    codigo_barra = models.CharField(max_length=50, unique=True)
    tamano_ml = models.IntegerField()
    imagen_url = models.URLField(max_length=255, null=True, blank=True)
    es_kit = models.BooleanField(default=False)

    def clean(self):
        if not self.codigo_barra:
            raise ValidationError('El código de barras es obligatorio.')
        if len(self.codigo_barra) < 8 or len(self.codigo_barra) > 13:
            raise ValidationError('El código de barras debe tener entre 8 y 13 dígitos.')
        
    def __str__(self):
        return f"{self.perfume.nombre} - {self.tamano_ml}ml - {self.codigo_barra}"
